﻿1.连接p-care
2.打开tftpd32.exe程序
3.点击标签 “Tftp Client”
4.所需填写内容如图1所示。BlockSize建议选择16384，不然会很慢
5.配置完成后点击put
6.wait ok
7.enjoy it ！